package troy.autofish.modmenu;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import troy.autofish.FabricModAutofish;
import troy.autofish.gui.AutofishScreenBuilder;

public class ModMenuApiAutofish implements ModMenuApi {
   public ConfigScreenFactory<?> getModConfigScreenFactory() {
      return (parent) -> {
         return AutofishScreenBuilder.buildScreen(FabricModAutofish.getInstance(), parent);
      };
   }
}
