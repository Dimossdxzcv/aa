package troy.autofish.scheduler;

public enum ActionType {
   RECAST,
   ROD_SWITCH,
   REPEATING_ACTION;

   // $FF: synthetic method
   private static ActionType[] $values() {
      return new ActionType[]{RECAST, ROD_SWITCH, REPEATING_ACTION};
   }
}
