package troy.autofish.scheduler;

import net.minecraft.class_156;

public class Action {
   private ActionType actionType;
   private long delay;
   private long timeToComplete;
   private Runnable runnable;

   public Action(ActionType actionType, long delay, Runnable runnable) {
      this.actionType = actionType;
      this.delay = delay;
      this.timeToComplete = class_156.method_658() + delay;
      this.runnable = runnable;
   }

   public boolean tick() {
      if (class_156.method_658() >= this.timeToComplete) {
         this.runnable.run();
         if (this.actionType == ActionType.REPEATING_ACTION) {
            this.timeToComplete = class_156.method_658() + this.delay;
         }

         return true;
      } else {
         return false;
      }
   }

   public ActionType getActionType() {
      return this.actionType;
   }

   public void resetTimer() {
      this.timeToComplete = class_156.method_658() + this.delay;
   }
}
