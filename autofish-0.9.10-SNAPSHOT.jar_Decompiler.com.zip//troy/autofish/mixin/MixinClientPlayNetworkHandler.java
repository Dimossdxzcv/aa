package troy.autofish.mixin;

import net.minecraft.class_2743;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import troy.autofish.FabricModAutofish;

@Mixin({class_634.class})
public class MixinClientPlayNetworkHandler {
   @Shadow
   private class_310 field_3690;

   @Inject(
      method = {"onPlaySound"},
      at = {@At("HEAD")}
   )
   public void onPlaySound(class_2767 playSoundS2CPacket_1, CallbackInfo ci) {
      if (this.field_3690.method_18854()) {
         FabricModAutofish.getInstance().handlePacket(playSoundS2CPacket_1);
      }

   }

   @Inject(
      method = {"onEntityVelocityUpdate"},
      at = {@At("HEAD")}
   )
   public void onVelocityUpdate(class_2743 entityVelocityUpdateS2CPacket_1, CallbackInfo ci) {
      if (this.field_3690.method_18854()) {
         FabricModAutofish.getInstance().handlePacket(entityVelocityUpdateS2CPacket_1);
      }

   }

   @Inject(
      method = {"onGameMessage"},
      at = {@At("HEAD")}
   )
   public void onChatMessage(class_7439 chatMessageS2CPacket_1, CallbackInfo ci) {
      if (this.field_3690.method_18854()) {
         FabricModAutofish.getInstance().handleChat(chatMessageS2CPacket_1);
      }

   }
}
