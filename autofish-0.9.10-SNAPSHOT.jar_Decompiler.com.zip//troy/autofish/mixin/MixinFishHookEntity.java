package troy.autofish.mixin;

import net.minecraft.class_1536;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import troy.autofish.FabricModAutofish;

@Mixin({class_1536.class})
public class MixinFishHookEntity {
   @Shadow
   private int field_7173;

   @Inject(
      method = {"tickFishingLogic"},
      at = {@At("TAIL")}
   )
   private void tickFishingLogic(class_2338 blockPos_1, CallbackInfo ci) {
      FabricModAutofish.getInstance().tickFishingLogic(((class_1536)this).method_24921(), this.field_7173);
   }
}
