package troy.autofish;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_7439;
import net.minecraft.class_3675.class_307;
import troy.autofish.config.Config;
import troy.autofish.config.ConfigManager;
import troy.autofish.gui.AutofishScreenBuilder;
import troy.autofish.scheduler.AutofishScheduler;

public class FabricModAutofish implements ClientModInitializer {
   private static FabricModAutofish instance;
   private Autofish autofish;
   private AutofishScheduler scheduler;
   private class_304 autofishGuiKey;
   private ConfigManager configManager;

   public void onInitializeClient() {
      if (instance == null) {
         instance = this;
      }

      this.configManager = new ConfigManager(this);
      this.autofishGuiKey = KeyBindingHelper.registerKeyBinding(new class_304("key.autofish.open_gui", class_307.field_1668, 86, "Autofish"));
      ClientTickEvents.END_CLIENT_TICK.register(this::tick);
      this.scheduler = new AutofishScheduler(this);
      this.autofish = new Autofish(this);
   }

   public void tick(class_310 client) {
      if (this.autofishGuiKey.method_1436()) {
         client.method_1507(AutofishScreenBuilder.buildScreen(this, client.field_1755));
      }

      this.autofish.tick(client);
      this.scheduler.tick(client);
   }

   public void handlePacket(class_2596<?> packet) {
      this.autofish.handlePacket(packet);
   }

   public void handleChat(class_7439 packet) {
      this.autofish.handleChat(packet);
   }

   public void tickFishingLogic(class_1297 owner, int ticksCatchable) {
      this.autofish.tickFishingLogic(owner, ticksCatchable);
   }

   public static FabricModAutofish getInstance() {
      return instance;
   }

   public Autofish getAutofish() {
      return this.autofish;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public Config getConfig() {
      return this.configManager.getConfig();
   }

   public AutofishScheduler getScheduler() {
      return this.scheduler;
   }
}
