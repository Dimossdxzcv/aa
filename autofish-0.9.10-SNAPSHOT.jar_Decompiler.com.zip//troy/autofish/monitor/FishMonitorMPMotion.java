package troy.autofish.monitor;

import net.minecraft.class_1536;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import troy.autofish.Autofish;

public class FishMonitorMPMotion implements FishMonitorMP {
   public static final int PACKET_MOTION_Y_THRESHOLD = -350;
   public static final int START_CATCHING_AFTER_THRESHOLD = 1000;
   private boolean hasHitWater = false;
   private long bobberRiseTimestamp = 0L;

   public void hookTick(Autofish autofish, class_310 minecraft, class_1536 hook) {
      if (worldContainsBlockWithMaterial(hook.method_37908(), hook.method_5829(), class_2246.field_10382)) {
         this.hasHitWater = true;
      }

   }

   public void handleHookRemoved() {
      this.hasHitWater = false;
      this.bobberRiseTimestamp = 0L;
   }

   public void handlePacket(Autofish autofish, class_2596<?> packet, class_310 minecraft) {
      if (packet instanceof class_2743) {
         class_2743 velocityPacket = (class_2743)packet;
         if (minecraft.field_1724 != null && minecraft.field_1724.field_7513 != null && minecraft.field_1724.field_7513.method_5628() == velocityPacket.method_11818()) {
            if (this.hasHitWater && this.bobberRiseTimestamp == 0L && velocityPacket.method_11816() > 0) {
               this.bobberRiseTimestamp = autofish.timeMillis;
            }

            long timeInWater = autofish.timeMillis - this.bobberRiseTimestamp;
            if (this.hasHitWater && this.bobberRiseTimestamp != 0L && timeInWater > 1000L && velocityPacket.method_11815() == 0 && velocityPacket.method_11819() == 0 && velocityPacket.method_11816() < -350) {
               autofish.catchFish();
               this.handleHookRemoved();
            }
         }
      }

   }

   public static boolean worldContainsBlockWithMaterial(class_1937 world, class_238 box, class_2248 block) {
      int i = class_3532.method_15357(box.field_1323);
      int j = class_3532.method_15384(box.field_1320);
      int k = class_3532.method_15357(box.field_1322);
      int l = class_3532.method_15384(box.field_1325);
      int m = class_3532.method_15357(box.field_1321);
      int n = class_3532.method_15384(box.field_1324);
      return class_2338.method_17962(i, k, m, j - 1, l - 1, n - 1).anyMatch((blockPos) -> {
         return world.method_8320(blockPos).method_26204() == block;
      });
   }
}
