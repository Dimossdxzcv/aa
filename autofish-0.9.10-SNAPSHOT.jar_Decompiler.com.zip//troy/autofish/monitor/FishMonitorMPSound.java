package troy.autofish.monitor;

import net.minecraft.class_1536;
import net.minecraft.class_2596;
import net.minecraft.class_2765;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import troy.autofish.Autofish;

public class FishMonitorMPSound implements FishMonitorMP {
   public static final double HOOKSOUND_DISTANCESQ_THRESHOLD = 25.0D;

   public void hookTick(Autofish autofish, class_310 minecraft, class_1536 hook) {
   }

   public void handleHookRemoved() {
   }

   public void handlePacket(Autofish autofish, class_2596<?> packet, class_310 minecraft) {
      if (packet instanceof class_2767 || packet instanceof class_2765) {
         if (!(packet instanceof class_2767)) {
            return;
         }

         class_2767 soundPacket = (class_2767)packet;
         class_3414 soundEvent = (class_3414)soundPacket.method_11894().comp_349();
         String soundName = soundEvent.method_14833().toString();
         double x = soundPacket.method_11890();
         double y = soundPacket.method_11889();
         double z = soundPacket.method_11893();
         if ((soundName.equalsIgnoreCase("minecraft:entity.fishing_bobber.splash") || soundName.equalsIgnoreCase("entity.fishing_bobber.splash")) && minecraft.field_1724 != null) {
            class_1536 hook = minecraft.field_1724.field_7513;
            if (hook != null && hook.method_5649(x, y, z) < 25.0D) {
               autofish.catchFish();
            }
         }
      }

   }
}
