package troy.autofish.monitor;

import net.minecraft.class_1536;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import troy.autofish.Autofish;

public interface FishMonitorMP {
   void hookTick(Autofish var1, class_310 var2, class_1536 var3);

   void handleHookRemoved();

   void handlePacket(Autofish var1, class_2596<?> var2, class_310 var3);
}
