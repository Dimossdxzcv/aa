package troy.autofish.gui;

import java.util.function.Function;
import me.shedaniel.clothconfig2.api.AbstractConfigListEntry;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import me.shedaniel.clothconfig2.impl.builders.SubCategoryBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import troy.autofish.FabricModAutofish;
import troy.autofish.config.Config;

public class AutofishScreenBuilder {
   private static final Function<Boolean, class_2561> yesNoTextSupplier = (bool) -> {
      return bool ? class_2561.method_43471("options.autofish.toggle.on") : class_2561.method_43471("options.autofish.toggle.off");
   };

   public static class_437 buildScreen(FabricModAutofish modAutofish, class_437 parentScreen) {
      Config defaults = new Config();
      Config config = modAutofish.getConfig();
      ConfigBuilder builder = ConfigBuilder.create().setParentScreen(parentScreen).setTitle(class_2561.method_43471("options.autofish.title")).transparentBackground().setDoesConfirmSave(true).setSavingRunnable(() -> {
         modAutofish.getConfig().enforceConstraints();
         modAutofish.getConfigManager().writeConfig(true);
      });
      ConfigEntryBuilder entryBuilder = builder.entryBuilder();
      ConfigCategory configCat = builder.getOrCreateCategory(class_2561.method_43471("options.autofish.config"));
      AbstractConfigListEntry toggleAutofish = entryBuilder.startBooleanToggle(class_2561.method_43471("options.autofish.enable.title"), config.isAutofishEnabled()).setDefaultValue(defaults.isAutofishEnabled()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.enable.tooltip")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setAutofishEnabled(newValue);
      }).setYesNoTextSupplier(yesNoTextSupplier).build();
      AbstractConfigListEntry toggleMultiRod = entryBuilder.startBooleanToggle(class_2561.method_43471("options.autofish.multirod.title"), config.isMultiRod()).setDefaultValue(defaults.isMultiRod()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.multirod.tooltip_0"), class_2561.method_43471("options.autofish.multirod.tooltip_1"), class_2561.method_43471("options.autofish.multirod.tooltip_2")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setMultiRod(newValue);
      }).setYesNoTextSupplier(yesNoTextSupplier).build();
      AbstractConfigListEntry toggleBreakProtection = entryBuilder.startBooleanToggle(class_2561.method_43471("options.autofish.break_protection.title"), config.isNoBreak()).setDefaultValue(defaults.isNoBreak()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.break_protection.tooltip_0"), class_2561.method_43471("options.autofish.break_protection.tooltip_1")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setNoBreak(newValue);
      }).setYesNoTextSupplier(yesNoTextSupplier).build();
      AbstractConfigListEntry togglePersistentMode = entryBuilder.startBooleanToggle(class_2561.method_43471("options.autofish.persistent.title"), config.isPersistentMode()).setDefaultValue(defaults.isPersistentMode()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.persistent.tooltip_0"), class_2561.method_43471("options.autofish.persistent.tooltip_1"), class_2561.method_43471("options.autofish.persistent.tooltip_2"), class_2561.method_43471("options.autofish.persistent.tooltip_3"), class_2561.method_43471("options.autofish.persistent.tooltip_4"), class_2561.method_43471("options.autofish.persistent.tooltip_5")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setPersistentMode(newValue);
      }).setYesNoTextSupplier(yesNoTextSupplier).build();
      AbstractConfigListEntry toggleSoundDetection = entryBuilder.startBooleanToggle(class_2561.method_43471("options.autofish.sound.title"), config.isUseSoundDetection()).setDefaultValue(defaults.isUseSoundDetection()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.sound.tooltip_0"), class_2561.method_43471("options.autofish.sound.tooltip_1"), class_2561.method_43471("options.autofish.sound.tooltip_2"), class_2561.method_43471("options.autofish.sound.tooltip_3"), class_2561.method_43471("options.autofish.sound.tooltip_4"), class_2561.method_43471("options.autofish.sound.tooltip_5"), class_2561.method_43471("options.autofish.sound.tooltip_6"), class_2561.method_43471("options.autofish.sound.tooltip_7"), class_2561.method_43471("options.autofish.sound.tooltip_8"), class_2561.method_43471("options.autofish.sound.tooltip_9")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setUseSoundDetection(newValue);
         modAutofish.getAutofish().setDetection();
      }).setYesNoTextSupplier(yesNoTextSupplier).build();
      AbstractConfigListEntry toggleForceMPDetection = entryBuilder.startBooleanToggle(class_2561.method_43471("options.autofish.multiplayer_compat.title"), config.isForceMPDetection()).setDefaultValue(defaults.isPersistentMode()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.multiplayer_compat.tooltip_0"), class_2561.method_43471("options.autofish.multiplayer_compat.tooltip_1"), class_2561.method_43471("options.autofish.multiplayer_compat.tooltip_2")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setForceMPDetection(newValue);
      }).setYesNoTextSupplier(yesNoTextSupplier).build();
      AbstractConfigListEntry recastDelaySlider = entryBuilder.startLongSlider(class_2561.method_43471("options.autofish.recast_delay.title"), config.getRecastDelay(), 500L, 5000L).setDefaultValue(defaults.getRecastDelay()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.recast_delay.tooltip_0"), class_2561.method_43471("options.autofish.recast_delay.tooltip_1")}).setTextGetter((value) -> {
         return class_2561.method_43469("options.autofish.recast_delay.value", new Object[]{value});
      }).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setRecastDelay(newValue);
      }).build();
      AbstractConfigListEntry clearLagRegexField = entryBuilder.startTextField(class_2561.method_43471("options.autofish.clear_regex.title"), config.getClearLagRegex()).setDefaultValue(defaults.getClearLagRegex()).setTooltip(new class_2561[]{class_2561.method_43471("options.autofish.clear_regex.tooltip_0"), class_2561.method_43471("options.autofish.clear_regex.tooltip_1"), class_2561.method_43471("options.autofish.clear_regex.tooltip_2")}).setSaveConsumer((newValue) -> {
         modAutofish.getConfig().setClearLagRegex(newValue);
      }).build();
      SubCategoryBuilder subCatBuilderBasic = entryBuilder.startSubCategory(class_2561.method_43471("options.autofish.basic.title"));
      subCatBuilderBasic.add(toggleAutofish);
      subCatBuilderBasic.add(toggleMultiRod);
      subCatBuilderBasic.add(toggleBreakProtection);
      subCatBuilderBasic.add(togglePersistentMode);
      subCatBuilderBasic.setExpanded(true);
      SubCategoryBuilder subCatBuilderAdvanced = entryBuilder.startSubCategory(class_2561.method_43471("options.autofish.advanced.title"));
      subCatBuilderAdvanced.add(toggleSoundDetection);
      subCatBuilderAdvanced.add(toggleForceMPDetection);
      subCatBuilderAdvanced.add(recastDelaySlider);
      subCatBuilderAdvanced.add(clearLagRegexField);
      subCatBuilderAdvanced.setExpanded(true);
      configCat.addEntry(subCatBuilderBasic.build());
      configCat.addEntry(subCatBuilderAdvanced.build());
      return builder.build();
   }
}
