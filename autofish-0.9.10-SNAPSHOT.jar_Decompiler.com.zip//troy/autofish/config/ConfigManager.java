package troy.autofish.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.nio.charset.Charset;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import net.fabricmc.loader.api.FabricLoader;
import org.apache.commons.io.FileUtils;
import troy.autofish.FabricModAutofish;

public class ConfigManager {
   private Config config;
   private FabricModAutofish modAutofish;
   private Gson gson;
   private File configFile;
   private Executor executor = Executors.newSingleThreadExecutor();

   public ConfigManager(FabricModAutofish modAutofish) {
      this.modAutofish = modAutofish;
      this.gson = (new GsonBuilder()).setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();
      this.configFile = new File(FabricLoader.getInstance().getConfigDir().toFile(), "autofish.config");
      this.readConfig(false);
   }

   public void readConfig(boolean async) {
      Runnable task = () -> {
         try {
            if (this.configFile.exists()) {
               String fileContents = FileUtils.readFileToString(this.configFile, Charset.defaultCharset());
               this.config = (Config)this.gson.fromJson(fileContents, Config.class);
               if (this.config.enforceConstraints()) {
                  this.writeConfig(true);
               }
            } else {
               this.writeNewConfig();
            }
         } catch (Exception var2) {
            var2.printStackTrace();
            this.writeNewConfig();
         }

      };
      if (async) {
         this.executor.execute(task);
      } else {
         task.run();
      }

   }

   public void writeNewConfig() {
      this.config = new Config();
      this.writeConfig(false);
   }

   public void writeConfig(boolean async) {
      Runnable task = () -> {
         try {
            if (this.config != null) {
               String serialized = this.gson.toJson(this.config);
               FileUtils.writeStringToFile(this.configFile, serialized, Charset.defaultCharset());
            }
         } catch (Exception var2) {
            var2.printStackTrace();
         }

      };
      if (async) {
         this.executor.execute(task);
      } else {
         task.run();
      }

   }

   public Config getConfig() {
      return this.config;
   }
}
